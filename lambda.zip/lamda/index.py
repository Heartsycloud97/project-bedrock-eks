import json

def lambda_handler(event, context):
    print("File uploaded to S3!")

    return {
        'statusCode': 200,
        'body': json.dumps('Success')
    }